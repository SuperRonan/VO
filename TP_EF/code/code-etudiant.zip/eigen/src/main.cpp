#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <visp3/core/vpImage.h>
#include <visp3/io/vpImageIo.h>
#include "EigenFacesDB.h"



void  writeEigenFaceInImage(int m_w, int m_h, const std::string& path, vpColVector &v)
{
    double maxV = v.getMaxValue();
    double minV = v.getMinValue();
    vpImage<unsigned char> I(m_h,m_w);
    for(int i=0; i<m_h; i++)
        for(int j = 0; j<m_w; j++)
        {
            I[i][j] = ((v[i*m_w+j]-minV)/(maxV-minV))*255;
        }
    vpImageIo::write(I, path);
}

void buildBDFaces(const std::vector<std::string>& paths, int maxEigenFace)
{
    int m_maxEigenFace = std::min(maxEigenFace, (int)paths.size());
    
    // On calcul les attibuts de l'image
    vpImage<unsigned char> I;
    vpImageIo::read(I,*paths.begin());
    int m_w = I.getWidth();
    int  m_h = I.getHeight();
    int m_size = m_h*m_w;
    
    std::cout << " * Caracteristique de l'images : " << m_h << "x" << m_w << std::endl;
    std::cout << " * Nombre d'image de la base : " << paths.size()<< std::endl;
    std::cout << " * Nombre de U : " << m_maxEigenFace << std::endl;
    
    // Creation du vpColVector pour le mean face
    std::cout << "[INFO] Creation Mean images ...." << std::endl;
    vpColVector m_vMean ;
    m_vMean = vpColVector(m_size);
   // buildMeanImage(paths);
    
    // Calcul de la matrice A
    std::cout << "[INFO] Calcul de A ... " << std::endl;
    /// vpMatrix A =  ;
    
    
    std::cout << "[INFO] Fin calcul BD ... " << std::endl;
}



std::vector<std::string> buildPathImagesAttFaces()
{
	std::vector<std::string> v;
	for(int nbDir=1; nbDir<=40; nbDir++)
		for(int nbImage=1; nbImage<10;nbImage++)
		{
			std::ostringstream ss;
			ss << "../Donnees/att_faces/s" << nbDir << "/" << nbImage << ".pgm";
			v.push_back(ss.str());
		}
	return v;
}

int main()
{
	std::cout << "[INFO] Construction du path ..." << std::endl;
	std::vector<std::string> paths = buildPathImagesAttFaces();
	std::cout << "[INFO] Creation de base de donnees ..." << std::endl;
	
    buildBDFaces(paths,400);
	
	return 0;
}
